const fs = require('fs');
const path = require('path');

// List of CSS files to compare
// const cssFiles = ['index', 'index2', 'index3'];
const cssFiles = ['standard-library'];

// Function to compare CSS files and generate the report
const compareCssFiles = (originalCssPath, purifiedCssPath) => {
    const originalCss = fs.readFileSync(originalCssPath, 'utf-8').split('\n');
    const purifiedCss = fs.readFileSync(purifiedCssPath, 'utf-8').split('\n');

    const unusedCss = originalCss.filter(line => !purifiedCss.includes(line) && line.trim() !== '');

    return { unusedCss, purifiedCss };
};

// Initialize HTML content
let htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PurgeCSS Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f9f9f9;
        }
        h1, h2 {
            color: #333;
        }
        .unused-css {
            color: red;
            font-weight: bold;
        }
        .used-css {
            color: green;
            font-weight: normal;
        }
        pre {
            background-color: #eee;
            padding: 10px;
            border-radius: 4px;
            overflow-x: auto;
        }
        .file-title {
            margin-top: 40px;
        }
    </style>
</head>
<body>
    <h1>PurgeCSS Report</h1>
`;

// Loop through each CSS file and generate the report
cssFiles.forEach(file => {
    const originalCssPath = path.join(__dirname, 'src', `${file}.scss`);
    const purifiedCssPath = path.join(__dirname, 'src', `${file}.purged.scss`);

    if (fs.existsSync(originalCssPath) && fs.existsSync(purifiedCssPath)) {
        const { unusedCss, purifiedCss } = compareCssFiles(originalCssPath, purifiedCssPath);

        htmlContent += `
        <div class="file-title"><h2>${file}.scss</h2></div>
        <h3>Unused CSS</h3>
        <pre class="unused-css">
        ${unusedCss.join('\n')}
        </pre>
        <h3>All Used CSS (for reference)</h3>
        <pre class="used-css">
        ${purifiedCss.join('\n')}
        </pre>
        `;
    } else {
        htmlContent += `<div class="file-title"><h2>${file}.scss</h2></div><p>Original or purified CSS file not found.</p>`;
    }
});

htmlContent += `
</body>
</html>
`;

// Write the HTML content to a file
const reportPath = path.join(__dirname, 'purgecss-report.html');
fs.writeFileSync(reportPath, htmlContent, 'utf-8');

console.log(`PurgeCSS HTML Report generated: ${reportPath}`);
