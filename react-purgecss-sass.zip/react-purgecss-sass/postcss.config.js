// postcss.config.js
// module.exports = {
//     plugins: [
//       require('autoprefixer'),
//       require('@fullhuman/postcss-purgecss')({
//         content: [
//           './src/**/*.html',
//           './src/**/*.js',
//           './src/**/*.jsx',
//           './src/**/*.ts',
//           './src/**/*.tsx',
//         ],
//         css: ['./src/**/*.css', './src/**/*.scss'],
//         defaultExtractor: content => content.match(/[\w-/:]+(?<!:)/g) || [],
//       }),
//     ],
//   };
  // module.exports = {
  //   plugins: [
  //     require('autoprefixer'),
  //     require('@fullhuman/postcss-purgecss')({
  //       content: ['./src/**/*.html', './src/**/*.js', './src/**/*.jsx', './src/**/*.tsx'],
  //       css: ['./src/**/*.css', './src/**/*.scss'],
  //       defaultExtractor: content => content.match(/[\w-/:]+(?<!:)/g) || [],
  //       safelist: ['safelist'], // if you have any classes you want to keep
  //     }),
  //   ],
  // };
  
  module.exports = {
    parser: 'postcss-scss', // Use the SCSS parser to handle SCSS syntax
    plugins: [
        require('postcss-import'), // Import CSS files
        require('postcss-mixins'), // Support for CSS mixins
        require('postcss-nested'), // Unwrap nested rules
        require('postcss-advanced-variables'), // Support for SCSS-like variables
        require('postcss-simple-vars'), // Support for simple variables
        require('postcss-custom-media'), // Custom Media Queries
        require('postcss-custom-selectors'), // Custom selectors
        require('postcss-preset-env')({ // Enable modern CSS features
            stage: 0, // Set the stage to 0 to enable all modern CSS features
            autoprefixer: { grid: true }, // Enable Autoprefixer with grid support
        }),
        require('autoprefixer'), // Add vendor prefixes automatically
        // require('cssnano')({ // Minify the CSS
        //     // preset: 'default',
        //     preset: ['default', {
        //       discardComments: { removeAll: true },
        //     }],
        // }),
        require('@fullhuman/postcss-purgecss')({ // Remove unused CSS
            content: [
                './src/**/*.html',
                './src/**/*.jsx',
                './src/**/*.js',
                './src/**/*.ts',
                './src/**/*.tsx',
            ],
            defaultExtractor: content => content.match(/[\w-/:]+(?<!:)/g) || [],
        }),
    ],
};
