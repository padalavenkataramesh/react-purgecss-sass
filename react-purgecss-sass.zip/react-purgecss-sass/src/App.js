// src/App.js
import React from 'react';
import './App.css';
import './index2.css';
import './index3.css';
import './standard-library.scss';
import './test.scss';
function App() {
  return (
    <div className="App">
      <div><button className="btn">Click Me</button></div>
      <br/>
      <div><button className="btn2">Button</button></div>
      <br/>
      <div><button className="font-w500">accessing key information such as company details</button></div>
      <br/>
      <div><button className="font-w600">accessing key information such as company details</button></div>
      <br/>
      <p className='graytext'>
      to generate Lorem Ipsum which looks reasonable.
      The generated Lorem Ipsum is therefore always.
      </p>
      <span className='ne-core-button1'>There are many variations of passages of Lorem Ipsum available, 
but the majority have suffered alteration in some form, by injected humour, 
or randomised words which don't look even slightly believable. 
If you are going to use a passage of Lorem Ipsum, 
you need to be sure there isn't anything embarrassing hidden in the middle of text. 
All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, 
making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words,
 combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable.
  The generated Lorem Ipsum is therefore always free from repetition, injected humour,
   or non-characteristic words etc.</span>
    </div>
  );
}

export default App;
